db_username = "cedbroot"
db_password = "cedbpassword"
db_name = "contentengine" 