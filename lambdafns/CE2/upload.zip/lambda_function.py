import boto3

def  getInterestsOfAllContacts(userid):
    result = []
    
    
    return ', '.join(result)
    
def lambda_handler(event, context): 
    users = {'1': {"email": "rachelwu313@gmail.com", "firstname": "Rachel", "lastname": "Wu"}} #userid
    for key in users.keys():
        user = users[key]
        keywords = getInterestsOfAllContacts(user)  #rds sql, a comma separated string of keywords/phrases 
        email = user["email"]
        firstname = user["firstname"]
        lastname = user["lastname"] 
        msgAttr = { 'email': {
                                'DataType': 'String',
                                'StringValue': email
                            },
                    'firstname': {
                                'DataType': 'String',
                                'StringValue': email
                            },
                    'lastname': {
                        'DataType': 'String',
                        'StringValue': email
                    },
                    'userID': {
                        'DataType': 'String',
                        'StringValue': key
                    },
                    'interests': {
                                'DataType': 'String',
                                'StringValue': keywords 
                            },
        }
    
    sqs = boto3.client('sqs')
    queue_url = 'https://sqs.us-east-1.amazonaws.com/073632995568/assistantcat'
    response = sqs.send_message(
        QueueUrl=queue_url,
        DelaySeconds=10,
        MessageAttributes={
            'phone': {
                'DataType': 'String',
                'StringValue': phone
            },
            'location': {
                'DataType': 'String',
                'StringValue': location
            },
            'numberppl': {
                'DataType': 'Number',
                'StringValue': numberppl
            },
            'diningtime': {
                'DataType': 'String',
                'StringValue': diningtime 
            },
            'cuisine': {
                'DataType': 'String',
                'StringValue': cuisine
            },
            "day": {
                "DataType": "String",
                "StringValue": day
            },
            "email": {
                "DataType": "String",
                "StringValue": email
            }
        },
        MessageBody=(
            'This is a message'
        )
    )
    
    print(response['MessageId'])
    return '' 