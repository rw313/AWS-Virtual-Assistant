from googlesearch import search
from textblob import TextBlob 

def lambda_handler(event, context):
    # TODO implement
    #event[''] #just 1 name, triggered when user clicks on name, and 1 description aka notes 
    #txt = 
    #for url in search('Tiffany Dufu news', stop=3):
    #    print(url)

    txt = """She is a biomedical student at Columbia university. She does research at the labs in the summer"""
    blob = TextBlob(txt) 
    return (blob.noun_phrases) 
